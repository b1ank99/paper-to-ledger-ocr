const { app, BrowserWindow, dialog, protocol, shell } = require("electron");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { Catalog } = require("./catalog.cjs");

function diagnostic(message) {
  if (!process.env.PTL_DIAGNOSTIC_FILE) return;
  try { fs.appendFileSync(process.env.PTL_DIAGNOSTIC_FILE, `${new Date().toISOString()} ${message}\n`); }
  catch { /* diagnostic logging must never stop the app */ }
}
process.on("uncaughtException", (error) => diagnostic(`Uncaught: ${error.stack || error}`));
process.on("unhandledRejection", (error) => diagnostic(`Rejected: ${error?.stack || error}`));
diagnostic("Main process started");
if (!app.isPackaged && process.env.PTL_TEST_USER_DATA) {
  fs.mkdirSync(process.env.PTL_TEST_USER_DATA, { recursive: true });
  app.setPath("userData", process.env.PTL_TEST_USER_DATA);
}

protocol.registerSchemesAsPrivileged([{ scheme: "paper", privileges: {
  standard: true, secure: true, supportFetchAPI: true, stream: true,
} }]);

let window = null;
let catalog = null;
let watchers = [];
let scanTimer = null;
const staticTypes = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".wasm": "application/wasm", ".gz": "application/gzip",
  ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".woff2": "font/woff2" };
const csp = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; worker-src 'self' blob:; child-src 'self' blob:; connect-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'";

function json(value, status = 200) {
  return Response.json(value, { status, headers: { "Cache-Control": "no-store" } });
}
function fail(error, status = 400) { return json({ error: error instanceof Error ? error.message : "Request failed." }, status); }
function settingsFile() { return path.join(app.getPath("userData"), "settings.json"); }
function suggestedRoot() { return path.join(app.getPath("home"), "Paper to Ledger Data"); }
function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile(), "utf8")); } catch { return {}; }
}
async function saveSettings(root) {
  await fsp.mkdir(app.getPath("userData"), { recursive: true });
  await fsp.writeFile(settingsFile(), JSON.stringify({ root }, null, 2), { encoding: "utf8", mode: 0o600 });
}
function config() { return { configured: Boolean(catalog), path: catalog?.root || "", suggestedPath: suggestedRoot() }; }

function stopWatching() {
  if (scanTimer) clearTimeout(scanTimer);
  scanTimer = null;
  for (const watcher of watchers) watcher.close();
  watchers = [];
}
function scheduleScan() {
  if (scanTimer) clearTimeout(scanTimer);
  scanTimer = setTimeout(async () => {
    scanTimer = null;
    if (!catalog) return;
    try {
      const count = await catalog.scan();
      if (count) window?.webContents.send("library-changed");
      watchFolders();
    } catch (error) { console.error("Folder scan failed:", error); }
  }, 600);
}
function watchFolders() {
  stopWatching();
  if (!catalog) return;
  const directories = [catalog.root, ...catalog.folders().map((folder) => path.join(catalog.root, folder.name))];
  for (const directory of directories) {
    try { watchers.push(fs.watch(directory, scheduleScan)); }
    catch (error) { console.warn("Could not watch folder:", directory, error); }
  }
}
async function useRoot(root) {
  const resolved = path.resolve(root);
  await fsp.mkdir(resolved, { recursive: true });
  const next = new Catalog(resolved);
  await next.scan();
  stopWatching();
  catalog?.close();
  catalog = next;
  await saveSettings(resolved);
  watchFolders();
  return config();
}

async function serveStatic(pathname) {
  const root = path.join(app.getAppPath(), "dist");
  const relative = pathname === "/" ? "index.html" : decodeURIComponent(pathname).replace(/^\/+/, "");
  const full = path.resolve(root, relative);
  diagnostic(`Static ${pathname} -> ${full}`);
  if (full !== root && !full.startsWith(root + path.sep)) return new Response("Not found", { status: 404 });
  let stat;
  try { stat = await fsp.stat(full); } catch { return new Response("Not found", { status: 404 }); }
  if (!stat.isFile()) return new Response("Not found", { status: 404 });
  const extension = path.extname(full).toLowerCase();
  return new Response(await fsp.readFile(full), { headers: {
    "Content-Type": staticTypes[extension] || "application/octet-stream",
    "Content-Security-Policy": csp,
    "X-Content-Type-Options": "nosniff",
    "Cache-Control": "no-store",
  } });
}

async function serveApi(request, pathname) {
  const method = request.method.toUpperCase();
  if (pathname === "/api/config" && method === "GET") return json(config());
  if (pathname === "/api/storage/default" && method === "POST") return json(await useRoot(suggestedRoot()));
  if (pathname === "/api/storage/choose" && method === "POST") {
    const picked = await dialog.showOpenDialog(window, { properties: ["openDirectory", "createDirectory"] });
    if (picked.canceled || !picked.filePaths[0]) return fail("No folder selected.");
    return json(await useRoot(picked.filePaths[0]));
  }
  if (!catalog) return fail("Choose a storage folder first.", 409);
  if (pathname === "/api/storage/open" && method === "POST") {
    const message = await shell.openPath(catalog.root);
    if (message) return fail(message);
    return json({ ok: true });
  }
  if (pathname === "/api/storage/backup" && method === "POST") {
    const picked = await dialog.showOpenDialog(window, { title: "Choose a separate backup location", properties: ["openDirectory", "createDirectory"] });
    if (picked.canceled || !picked.filePaths[0]) return fail("Backup cancelled.");
    const destination = await catalog.createBackup(picked.filePaths[0]);
    return json({ destination });
  }
  if (pathname === "/api/import" && method === "POST") {
    const picked = await dialog.showOpenDialog(window, { title: "Import photos or PDFs", properties: ["openFile", "multiSelections"], filters: [
      { name: "Images and PDFs", extensions: ["jpg", "jpeg", "png", "webp", "pdf"] },
    ] });
    if (picked.canceled) return json({ imported: [], cancelled: true });
    const body = await request.json().catch(() => ({}));
    const imported = [];
    for (const source of picked.filePaths) imported.push(await catalog.importPath(source, body.folderId || null));
    window?.webContents.send("library-changed");
    return json({ imported });
  }
  if (pathname === "/api/folders" && method === "GET") return json({ folders: catalog.folders() });
  if (pathname === "/api/folders" && method === "POST") {
    const body = await request.json();
    const folder = await catalog.createFolder(body.name);
    watchFolders();
    window?.webContents.send("library-changed");
    return json({ folder }, 201);
  }
  const folderMatch = /^\/api\/folders\/([\w-]+)$/.exec(pathname);
  if (folderMatch && method === "PATCH") {
    const body = await request.json();
    await catalog.renameFolder(folderMatch[1], body.name);
    watchFolders();
    window?.webContents.send("library-changed");
    return json({ ok: true });
  }
  if (pathname === "/api/documents" && method === "GET") {
    await catalog.scan();
    return json({ documents: catalog.allDocuments() });
  }
  if (pathname === "/api/documents" && method === "POST") {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return fail("Choose an image or PDF.");
    const result = await catalog.importBuffer(file.name, Buffer.from(await file.arrayBuffer()), String(form.get("folderId") || "") || null);
    window?.webContents.send("library-changed");
    return json(result, 201);
  }
  const documentMatch = /^\/api\/documents\/([\w-]+)(?:\/(image))?$/.exec(pathname);
  if (documentMatch) {
    const id = documentMatch[1];
    if (documentMatch[2] === "image" && method === "GET") {
      const row = catalog.getDocument(id);
      if (!row) return fail("Document not found.", 404);
      const full = catalog.fileFor(row);
      const stat = await fsp.lstat(full);
      if (!stat.isFile() || stat.isSymbolicLink()) return fail("Document is unavailable.", 404);
      return new Response(await fsp.readFile(full), { headers: {
        "Content-Type": row.content_type, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox",
      } });
    }
    if (method === "GET") return json({ document: catalog.fullDocument(id) });
    if (method === "PATCH") {
      const body = await request.json();
      await catalog.updateDocument(id, body);
      window?.webContents.send("library-changed");
      return json({ document: catalog.fullDocument(id) });
    }
  }
  return fail("Not found.", 404);
}

async function handle(request) {
  try {
    const url = new URL(request.url);
    diagnostic(`Request ${request.method} ${url.href}`);
    if (url.hostname !== "local") return new Response("Not found", { status: 404 });
    if (url.pathname.startsWith("/api/")) return await serveApi(request, url.pathname);
    if (request.method !== "GET") return new Response("Method not allowed", { status: 405 });
    return await serveStatic(url.pathname);
  } catch (error) { diagnostic(`Request failed: ${error.stack || error}`); console.error("App request failed:", error); return fail(error, 500); }
}

async function start() {
  diagnostic("Electron ready");
  protocol.handle("paper", handle);
  diagnostic(`Protocol handled: ${protocol.isProtocolHandled("paper")}`);
  const settings = readSettings();
  if (settings.root && typeof settings.root === "string" && fs.existsSync(settings.root)) {
    try { await useRoot(settings.root); }
    catch (error) { console.error("Could not open saved folder:", error); }
  }
  window = new BrowserWindow({ width: 1380, height: 900, minWidth: 860, minHeight: 600,
    title: "Paper to Ledger OCR", show: false,
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true,
      nodeIntegration: false, sandbox: true, webSecurity: true },
  });
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("paper://local/api/documents/") && url.endsWith("/image")) {
      return { action: "allow", overrideBrowserWindowOptions: { webPreferences: {
        contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true,
      } } };
    }
    return { action: "deny" };
  });
  window.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith("paper://local/")) event.preventDefault();
  });
  window.on("focus", scheduleScan);
  window.once("ready-to-show", () => window.show());
  await window.loadURL("paper://local/");
  diagnostic("Window loaded");
}

app.whenReady().then(start).catch((error) => { diagnostic(`Startup failed: ${error.stack || error}`); console.error(error); app.quit(); });
app.on("window-all-closed", () => app.quit());
app.on("before-quit", () => { stopWatching(); catalog?.close(); });
