const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");
const { DatabaseSync, backup } = require("node:sqlite");

const internalDirectory = ".paper-to-ledger";
const supported = new Set([".jpg", ".jpeg", ".png", ".webp", ".pdf"]);
const mime = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".pdf": "application/pdf" };
const invalidName = /[<>:"/\\|?*\x00-\x1f]/;
const reservedName = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i;

function validName(name) {
  return typeof name === "string" && name.length > 0 && name.length <= 180 &&
    name !== "." && name !== ".." && !name.endsWith(".") && !name.endsWith(" ") &&
    !invalidName.test(name) && !reservedName.test(name) && name !== internalDirectory;
}

function detectedType(bytes) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "image/png";
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "image/webp";
  if (bytes.length >= 5 && bytes.toString("ascii", 0, 5) === "%PDF-") return "application/pdf";
  return null;
}

function hashFile(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("sha256");
    const stream = fs.createReadStream(file);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", () => resolve(hash.digest("hex")));
  });
}

async function uniqueName(dir, requested) {
  const parsed = path.parse(requested);
  for (let index = 0; index < 10000; index++) {
    const name = index === 0 ? requested : `${parsed.name} (${index})${parsed.ext}`;
    try { await fsp.access(path.join(dir, name)); }
    catch (error) { if (error.code === "ENOENT") return name; throw error; }
  }
  throw new Error("Too many files with the same name.");
}

class Catalog {
  constructor(root) {
    this.root = path.resolve(root);
    fs.mkdirSync(path.join(this.root, internalDirectory), { recursive: true });
    this.db = new DatabaseSync(path.join(this.root, internalDirectory, "catalog.sqlite"));
    this.db.exec(`PRAGMA journal_mode=WAL;
      PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS folders (
        id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE, created_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS documents (
        id TEXT PRIMARY KEY, relative_path TEXT NOT NULL UNIQUE COLLATE NOCASE,
        folder_id TEXT REFERENCES folders(id), file_name TEXT NOT NULL,
        content_type TEXT NOT NULL, file_size INTEGER NOT NULL, mtime_ms INTEGER NOT NULL,
        sha256 TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Needs Review',
        ocr_text TEXT NOT NULL DEFAULT '', ocr_layout TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS documents_hash ON documents(sha256);
      CREATE INDEX IF NOT EXISTS documents_folder ON documents(folder_id);`);
    this.scanning = null;
  }

  close() { this.db.close(); }
  getFolder(id) {
    if (!id) return null;
    const folder = this.db.prepare("SELECT id, name FROM folders WHERE id = ?").get(id);
    if (!folder) throw new Error("Folder not found.");
    return folder;
  }
  directoryFor(folderId) { return path.join(this.root, this.getFolder(folderId)?.name || ""); }
  fileFor(row) {
    const absolute = path.resolve(this.root, row.relative_path);
    if (absolute !== this.root && !absolute.startsWith(this.root + path.sep)) throw new Error("Invalid document path.");
    return absolute;
  }
  getDocument(id) { return this.db.prepare("SELECT * FROM documents WHERE id = ?").get(id); }
  allDocuments() {
    return this.db.prepare(`SELECT id, folder_id AS folderId, file_name AS fileName,
      content_type AS contentType, status, source, created_at AS createdAt
      FROM documents ORDER BY created_at DESC, file_name COLLATE NOCASE`).all();
  }
  fullDocument(id) {
    const row = this.getDocument(id);
    if (!row) throw new Error("Document not found.");
    return { id: row.id, folderId: row.folder_id, fileName: row.file_name,
      contentType: row.content_type, status: row.status, ocrText: row.ocr_text,
      ocrLayout: row.ocr_layout, source: row.source, createdAt: row.created_at };
  }
  folders() { return this.db.prepare("SELECT id, name, created_at AS createdAt FROM folders ORDER BY name COLLATE NOCASE").all(); }

  async scan() {
    if (this.scanning) return this.scanning;
    this.scanning = this._scan().finally(() => { this.scanning = null; });
    return this.scanning;
  }
  async _scan() {
    const entries = await fsp.readdir(this.root, { withFileTypes: true });
    const dirs = [{ name: "", id: null }];
    for (const entry of entries) {
      if (!entry.isDirectory() || entry.name === internalDirectory || entry.name.startsWith(".")) continue;
      if (!validName(entry.name)) continue;
      let folder = this.db.prepare("SELECT id FROM folders WHERE name = ? COLLATE NOCASE").get(entry.name);
      if (!folder) {
        const id = crypto.randomUUID();
        this.db.prepare("INSERT INTO folders (id, name, created_at) VALUES (?, ?, ?)").run(id, entry.name, new Date().toISOString());
        folder = { id };
      }
      dirs.push({ name: entry.name, id: folder.id });
    }
    const seen = new Set();
    let changes = 0;
    for (const dir of dirs) {
      let children = entries;
      if (dir.name) {
        try { children = await fsp.readdir(path.join(this.root, dir.name), { withFileTypes: true }); }
        catch {
          for (const row of this.db.prepare("SELECT relative_path FROM documents WHERE folder_id = ?").all(dir.id)) seen.add(row.relative_path.toLowerCase());
          continue;
        }
      }
      for (const entry of children) {
        if (!entry.isFile() || !supported.has(path.extname(entry.name).toLowerCase())) continue;
        const relative = dir.name ? path.join(dir.name, entry.name) : entry.name;
        const absolute = path.join(this.root, relative);
        const stat = await fsp.stat(absolute).catch(() => null);
        if (!stat || !stat.isFile()) continue;
        seen.add(relative.toLowerCase());
        const existing = this.db.prepare("SELECT * FROM documents WHERE relative_path = ? COLLATE NOCASE").get(relative);
        if (existing && existing.file_size === stat.size && existing.mtime_ms === stat.mtimeMs) continue;
        const hash = await hashFile(absolute).catch(() => null);
        if (!hash) continue;
        const afterRead = await fsp.stat(absolute).catch(() => null);
        if (!afterRead || afterRead.size !== stat.size || afterRead.mtimeMs !== stat.mtimeMs) continue;
        const now = new Date().toISOString();
        if (existing) {
          const changed = existing.sha256 !== hash;
          this.db.prepare(`UPDATE documents SET file_size=?, mtime_ms=?, sha256=?,
            content_type=?, ocr_text=?, ocr_layout=?, source=?, status=?, updated_at=? WHERE id=?`)
            .run(stat.size, stat.mtimeMs, hash, mime[path.extname(entry.name).toLowerCase()],
              changed ? "" : existing.ocr_text, changed ? "" : existing.ocr_layout,
              changed ? "pending" : existing.source, changed ? "Needs Review" : existing.status, now, existing.id);
          changes++;
          continue;
        }
        const moved = this.db.prepare("SELECT * FROM documents WHERE sha256 = ?").all(hash)
          .find((row) => !fs.existsSync(this.fileFor(row)));
        if (moved) {
          this.db.prepare("UPDATE documents SET relative_path=?, folder_id=?, file_name=?, file_size=?, mtime_ms=?, updated_at=? WHERE id=?")
            .run(relative, dir.id, entry.name, stat.size, stat.mtimeMs, now, moved.id);
        } else {
          this.db.prepare(`INSERT INTO documents (id, relative_path, folder_id, file_name, content_type,
            file_size, mtime_ms, sha256, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
            .run(crypto.randomUUID(), relative, dir.id, entry.name, mime[path.extname(entry.name).toLowerCase()],
              stat.size, stat.mtimeMs, hash, now, now);
        }
        changes++;
      }
    }
    for (const row of this.db.prepare("SELECT id, relative_path FROM documents").all()) {
      if (!seen.has(row.relative_path.toLowerCase())) {
        this.db.prepare("DELETE FROM documents WHERE id = ?").run(row.id);
        changes++;
      }
    }
    for (const folder of this.db.prepare("SELECT id, name FROM folders").all()) {
      if (!dirs.some((dir) => dir.id === folder.id)) {
        this.db.prepare("DELETE FROM folders WHERE id = ?").run(folder.id);
        changes++;
      }
    }
    return changes;
  }

  async createFolder(name) {
    name = String(name || "").trim();
    if (!validName(name) || name.length > 60) throw new Error("Use a folder name up to 60 characters without Windows special characters.");
    if (this.db.prepare("SELECT id FROM folders WHERE name = ? COLLATE NOCASE").get(name)) throw new Error("A folder with that name already exists.");
    await fsp.mkdir(path.join(this.root, name));
    await this.scan();
    return this.db.prepare("SELECT id, name, created_at AS createdAt FROM folders WHERE name = ? COLLATE NOCASE").get(name);
  }
  async renameFolder(id, name) {
    const old = this.getFolder(id);
    name = String(name || "").trim();
    if (!validName(name) || name.length > 60) throw new Error("Use a folder name up to 60 characters without Windows special characters.");
    if (old.name.toLowerCase() !== name.toLowerCase() && this.db.prepare("SELECT id FROM folders WHERE name = ? COLLATE NOCASE").get(name)) throw new Error("A folder with that name already exists.");
    await fsp.rename(path.join(this.root, old.name), path.join(this.root, name));
    this.db.prepare("UPDATE folders SET name = ? WHERE id = ?").run(name, id);
    for (const row of this.db.prepare("SELECT id, file_name FROM documents WHERE folder_id = ?").all(id)) {
      this.db.prepare("UPDATE documents SET relative_path = ? WHERE id = ?").run(path.join(name, row.file_name), row.id);
    }
  }
  async updateDocument(id, body) {
    const row = this.getDocument(id);
    if (!row) throw new Error("Document not found.");
    if (Object.hasOwn(body, "fileName")) {
      let name = String(body.fileName || "").trim();
      const extension = path.extname(row.file_name);
      if (!path.extname(name)) name += extension;
      if (!validName(name) || path.extname(name).toLowerCase() !== extension.toLowerCase()) throw new Error("Choose a valid name with the same file type.");
      if (name !== row.file_name) {
        const destination = path.join(path.dirname(this.fileFor(row)), name);
        if (fs.existsSync(destination)) throw new Error("A file with that name already exists.");
        await fsp.rename(this.fileFor(row), destination);
        this.db.prepare("UPDATE documents SET file_name=?, relative_path=?, updated_at=? WHERE id=?")
          .run(name, row.folder_id ? path.join(this.getFolder(row.folder_id).name, name) : name, new Date().toISOString(), id);
      }
    }
    if (Object.hasOwn(body, "folderId")) {
      const current = this.getDocument(id);
      const folderId = body.folderId || null;
      const destinationDir = this.directoryFor(folderId);
      if (current.folder_id !== folderId) {
        const destination = path.join(destinationDir, current.file_name);
        if (fs.existsSync(destination)) throw new Error("That folder already has a file with this name.");
        await fsp.rename(this.fileFor(current), destination);
        this.db.prepare("UPDATE documents SET folder_id=?, relative_path=?, updated_at=? WHERE id=?")
          .run(folderId, folderId ? path.join(this.getFolder(folderId).name, current.file_name) : current.file_name, new Date().toISOString(), id);
      }
    }
    for (const [key, column, max] of [["ocrText", "ocr_text", 50000], ["ocrLayout", "ocr_layout", 1000000], ["source", "source", 30], ["status", "status", 30]]) {
      if (Object.hasOwn(body, key)) {
        const value = String(body[key] ?? "");
        if (value.length > max) throw new Error(`${key} is too long.`);
        this.db.prepare(`UPDATE documents SET ${column}=?, updated_at=? WHERE id=?`).run(value, new Date().toISOString(), id);
      }
    }
  }

  async importBuffer(name, bytes, folderId) {
    if (!validName(name) || !supported.has(path.extname(name).toLowerCase())) throw new Error("Use a JPEG, PNG, WebP, or PDF file.");
    if (bytes.length < 1 || bytes.length > 100 * 1024 * 1024) throw new Error("File must be under 100 MB.");
    if (detectedType(bytes) !== mime[path.extname(name).toLowerCase()]) throw new Error("File contents do not match the file type.");
    const hash = crypto.createHash("sha256").update(bytes).digest("hex");
    const duplicate = this.db.prepare("SELECT id FROM documents WHERE sha256 = ? LIMIT 1").get(hash);
    if (duplicate) return { id: duplicate.id, duplicate: true };
    const dir = this.directoryFor(folderId);
    const unique = await uniqueName(dir, name);
    await fsp.writeFile(path.join(dir, unique), bytes, { flag: "wx" });
    await this.scan();
    const relative = folderId ? path.join(this.getFolder(folderId).name, unique) : unique;
    const row = this.db.prepare("SELECT id FROM documents WHERE relative_path = ? COLLATE NOCASE").get(relative);
    return { id: row.id, duplicate: false };
  }
  async importPath(source, folderId) {
    const stat = await fsp.stat(source);
    if (!stat.isFile() || stat.size > 100 * 1024 * 1024) throw new Error("Choose a file under 100 MB.");
    return this.importBuffer(path.basename(source), await fsp.readFile(source), folderId);
  }
  async createBackup(destinationParent) {
    const resolved = path.resolve(destinationParent);
    if (resolved === this.root || resolved.startsWith(this.root + path.sep)) throw new Error("Choose a backup folder outside the document folder.");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const destination = path.join(resolved, `Paper to Ledger backup ${stamp}`);
    await fsp.mkdir(destination);
    for (const entry of await fsp.readdir(this.root, { withFileTypes: true })) {
      if (entry.name === internalDirectory || entry.isSymbolicLink()) continue;
      await fsp.cp(path.join(this.root, entry.name), path.join(destination, entry.name), { recursive: true });
    }
    await fsp.mkdir(path.join(destination, internalDirectory));
    await backup(this.db, path.join(destination, internalDirectory, "catalog.sqlite"));
    return destination;
  }
}

module.exports = { Catalog, validName, supported, mime, internalDirectory };
