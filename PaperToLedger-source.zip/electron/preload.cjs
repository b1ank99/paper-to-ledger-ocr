const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("paperToLedger", {
  onLibraryChanged(callback) {
    if (typeof callback !== "function") return () => {};
    const listener = () => callback();
    ipcRenderer.on("library-changed", listener);
    return () => ipcRenderer.removeListener("library-changed", listener);
  },
});
