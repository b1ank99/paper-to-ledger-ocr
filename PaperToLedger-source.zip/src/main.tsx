import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import Workspace from "./workspace";
import "./globals.css";

type Config = { configured: boolean; path: string; suggestedPath: string };

function DesktopApp() {
  const [config, setConfig] = useState<Config | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { void fetch("/api/config").then((r) => r.json()).then(setConfig).catch((e) => setError(e.message)); }, []);

  async function setup(choice: "default" | "choose") {
    setBusy(true); setError("");
    try {
      const response = await fetch(`/api/storage/${choice}`, { method: "POST" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not choose storage folder.");
      setConfig(data);
    } catch (e) { setError((e as Error).message); }
    finally { setBusy(false); }
  }

  if (error && !config) return <div className="setup"><h1>Paper to Ledger OCR</h1><p role="alert">{error}</p></div>;
  if (!config) return <div className="setup"><h1>Paper to Ledger OCR</h1><p>Opening your local library…</p></div>;
  if (!config.configured) return <div className="setup"><h1>Choose where to keep your documents</h1><p>Photos, PDFs, and corrected text stay on this PC. You can copy files into this folder later, and they will appear in the app.</p><code>{config.suggestedPath}</code><div className="setup-actions"><button className="btn primary" disabled={busy} onClick={() => void setup("default")}>Use this folder</button><button className="btn" disabled={busy} onClick={() => void setup("choose")}>Choose another folder</button></div>{error && <p role="alert">{error}</p>}</div>;
  return <Workspace userName="On this PC" storagePath={config.path} />;
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><DesktopApp /></React.StrictMode>);
