export type PhotoIssue = "small" | "blurry" | "dark" | "unchecked";

export type PhotoQuality = {
  issues: PhotoIssue[];
  sharpness: number;
  brightness: number;
};

// A warning heuristic, not a verdict: texture, glare, and sparse text can fool it.
export function assessPhotoQuality(
  pixels: Uint8ClampedArray,
  width: number,
  height: number,
  originalWidth = width,
  originalHeight = height,
): PhotoQuality {
  if (width < 3 || height < 3 || pixels.length < width * height * 4) {
    return { issues: ["unchecked"], sharpness: 0, brightness: 0 };
  }

  const issues: PhotoIssue[] = [];
  if (Math.min(originalWidth, originalHeight) < 700 || originalWidth * originalHeight < 600_000) issues.push("small");

  const gray = new Uint8Array(width * height);
  let brightnessSum = 0;
  for (let index = 0; index < gray.length; index++) {
    const pixel = index * 4;
    const value = Math.round(0.2126 * pixels[pixel] + 0.7152 * pixels[pixel + 1] + 0.0722 * pixels[pixel + 2]);
    gray[index] = value;
    brightnessSum += value;
  }
  const brightness = brightnessSum / gray.length;
  if (brightness < 65) issues.push("dark");

  // Mean of the strongest 1% of local edges avoids diluting text with white paper.
  const histogram = new Uint32Array(256);
  let samples = 0;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const index = y * width + x;
      const edge = Math.min(255, Math.abs(4 * gray[index] - gray[index - 1] - gray[index + 1] - gray[index - width] - gray[index + width]));
      histogram[edge]++;
      samples++;
    }
  }
  let remaining = Math.max(1, Math.ceil(samples * 0.01));
  const topCount = remaining;
  let edgeSum = 0;
  for (let value = 255; value >= 0 && remaining > 0; value--) {
    const count = Math.min(remaining, histogram[value]);
    edgeSum += value * count;
    remaining -= count;
  }
  const sharpness = edgeSum / topCount;
  if (sharpness < 28) issues.push("blurry");
  return { issues, sharpness, brightness };
}

export function needsOcrReview(words: Array<{ confidence: number }>, overallConfidence?: number): boolean {
  if (overallConfidence !== undefined && overallConfidence < 70) return true;
  return words.length > 0 && words.filter((word) => word.confidence < 60).length >= Math.max(2, Math.ceil(words.length * 0.2));
}
