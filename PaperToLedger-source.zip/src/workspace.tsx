"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { PDFDocumentProxy, RenderTask } from "pdfjs-dist";
import OcrTextLayer from "./ocr-text-layer";
import { parseOcrLayout } from "./ocr-layout";
import { assessPhotoQuality, needsOcrReview } from "./photo-quality";
import type { PhotoIssue } from "./photo-quality";

type QueueItem = { id: string; fileName: string; contentType: string; folderId: string | null; createdAt: string };
type Document = QueueItem & { contentType: string; ocrText: string; ocrLayout: string; source: string };
type Folder = { id: string; name: string; createdAt: string };
type Notice = { text: string; error?: boolean };
type OcrWorker = Awaited<ReturnType<typeof import("tesseract.js")["createWorker"]>>;
type PendingPhoto = { file: File; url: string; source: "camera" | "upload"; issues: PhotoIssue[] };
const maxUploadBytes = 100 * 1024 * 1024;
const photoIssueMessage: Record<PhotoIssue, string> = {
  blurry: "The text may be blurry. Try holding the phone steady and tapping the text to focus.",
  small: "This image may be too small for reliable reading. Move closer so the document fills the frame.",
  dark: "This photo looks dark. Try brighter, even lighting without glare.",
  unchecked: "We could not check this photo's clarity. Please zoom in and inspect the text before using it.",
};

async function api<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, { cache: "no-store", ...options });
  const data = await response.json().catch(() => ({})) as { error?: string };
  if (!response.ok) throw new Error(data.error || "The request failed.");
  return data as T;
}

async function prepareImage(file: File): Promise<{ file: File; resized: boolean }> {
  if (file.size > maxUploadBytes) throw new Error("Choose a file under 100 MB.");
  return { file, resized: false };
}

async function checkPhoto(file: File): Promise<PhotoIssue[]> {
  const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  try {
    const scale = Math.min(1, 1200 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) return ["unchecked"];
    context.fillStyle = "white";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    return assessPhotoQuality(context.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height, bitmap.width, bitmap.height).issues;
  } finally { bitmap.close(); }
}

async function createOcrWorker(onProgress: (message: string) => void): Promise<OcrWorker> {
  const { createWorker } = await import("tesseract.js");
  return createWorker("eng", 1, {
    workerPath: "/ocr/worker.min.js", corePath: "/ocr/core", langPath: "/ocr/lang",
    logger: (event) => { if (event.status) onProgress(`${event.status}${event.progress ? ` ${Math.round(event.progress * 100)}%` : ""}`); },
  });
}

declare global { interface Window { paperToLedger?: { onLibraryChanged: (callback: () => void) => () => void } } }

export default function Workspace({ userName, storagePath }: { userName: string; storagePath: string }) {
  const [documents, setDocuments] = useState<QueueItem[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [activeFolder, setActiveFolder] = useState("all");
  const [search, setSearch] = useState("");
  const [newFolder, setNewFolder] = useState(false);
  const [folderName, setFolderName] = useState("");
  const [renamingFolder, setRenamingFolder] = useState(false);
  const [renameTarget, setRenameTarget] = useState<{ id: string; surface: "card" | "header" } | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [pendingPhoto, setPendingPhoto] = useState<PendingPhoto | null>(null);
  const [qualityZoom, setQualityZoom] = useState(false);
  const [selectedId, setSelectedId] = useState("");
  const [doc, setDoc] = useState<Document | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [busy, setBusy] = useState("");
  const [progress, setProgress] = useState("");
  const [zoom, setZoom] = useState(100);
  const [pdfPage, setPdfPage] = useState(1);
  const [pdfPageCount, setPdfPageCount] = useState(0);
  const [pdfLoading, setPdfLoading] = useState(false);
  const [moveImage, setMoveImage] = useState(false);
  const pdfRef = useRef<PDFDocumentProxy | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const textRef = useRef<HTMLTextAreaElement | null>(null);
  const docId = doc?.id;
  const docType = doc?.contentType;
  const layout = parseOcrLayout(doc?.ocrLayout || "");
  const uncertainOcr = !!layout && needsOcrReview(layout.words, layout.overallConfidence);
  const visibleDocuments = documents.filter((item) => (activeFolder === "all" || (activeFolder === "unfiled" ? !item.folderId : item.folderId === activeFolder)) && item.fileName.toLowerCase().includes(search.toLowerCase()));
  const folderNameFor = (folderId: string | null) => folders.find((folder) => folder.id === folderId)?.name || "Unfiled";

  const refreshDocuments = useCallback(async () => {
    const result = await api<{ documents: QueueItem[] }>("/api/documents");
    setDocuments(result.documents);
    setSelectedId((current) => current || result.documents[0]?.id || "");
  }, []);

  const refreshFolders = useCallback(async () => {
    const result = await api<{ folders: Folder[] }>("/api/folders");
    setFolders(result.folders);
  }, []);

  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { refreshDocuments().catch((error) => setNotice({ text: error.message, error: true })); }, [refreshDocuments]);
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { refreshFolders().catch((error) => setNotice({ text: error.message, error: true })); }, [refreshFolders]);
  useEffect(() => {
    const refresh = () => { void refreshDocuments(); void refreshFolders(); };
    const unsubscribe = window.paperToLedger?.onLibraryChanged(refresh);
    window.addEventListener("focus", refresh);
    return () => { unsubscribe?.(); window.removeEventListener("focus", refresh); };
  }, [refreshDocuments, refreshFolders]);
  useEffect(() => {
    if (!previewOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") setPreviewOpen(false); };
    window.addEventListener("keydown", closeOnEscape);
    return () => { window.removeEventListener("keydown", closeOnEscape); document.body.style.overflow = previousOverflow; };
  }, [previewOpen]);
  useEffect(() => {
    if (!pendingPhoto) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") setPendingPhoto(null); };
    window.addEventListener("keydown", closeOnEscape);
    return () => { window.removeEventListener("keydown", closeOnEscape); document.body.style.overflow = previousOverflow; URL.revokeObjectURL(pendingPhoto.url); };
  }, [pendingPhoto]);
  useEffect(() => {
    if (!selectedId) return;
    let active = true;
    api<{ document: Document }>(`/api/documents/${selectedId}`)
      .then((result) => { if (active) setDoc(result.document); })
      .catch((error) => { if (active) setNotice({ text: error.message, error: true }); });
    return () => { active = false; };
  }, [selectedId]);

  useEffect(() => {
    if (!docId || docType !== "application/pdf") { pdfRef.current = null; return; }
    let active = true;
    let loadingTask: ReturnType<typeof import("pdfjs-dist")["getDocument"]> | null = null;
    (async () => {
      const response = await fetch(`/api/documents/${docId}/image`, { cache: "no-store" });
      if (!response.ok) throw new Error("Could not open the PDF.");
      if (active) setPdfLoading(true);
      const pdfjs = await import("pdfjs-dist");
      pdfjs.GlobalWorkerOptions.workerSrc = "/pdf/pdf.worker.min.mjs";
      loadingTask = pdfjs.getDocument({ data: new Uint8Array(await response.arrayBuffer()) });
      const pdf = await loadingTask.promise;
      if (!active) return;
      pdfRef.current = pdf;
      setPdfPageCount(pdf.numPages);
    })().catch((error) => { if (active) { setPdfLoading(false); setNotice({ text: `PDF preview failed: ${(error as Error).message}`, error: true }); } });
    return () => { active = false; pdfRef.current = null; void loadingTask?.destroy(); };
  }, [docId, docType]);

  useEffect(() => {
    if (!docId || docType !== "application/pdf" || !pdfPageCount || !pdfRef.current || !canvasRef.current) return;
    let active = true;
    let renderTask: RenderTask | undefined;
    const pdf = pdfRef.current;
    const canvas = canvasRef.current;
    (async () => {
      const page = await pdf.getPage(pdfPage);
      const base = page.getViewport({ scale: 1 });
      const viewport = page.getViewport({ scale: Math.min(3, 2200 / base.width) });
      canvas.width = Math.ceil(viewport.width);
      canvas.height = Math.ceil(viewport.height);
      renderTask = page.render({ canvas, viewport });
      await renderTask.promise;
      if (active) setPdfLoading(false);
    })().catch((error) => { if (active) setNotice({ text: `Could not display this PDF page: ${(error as Error).message}`, error: true }); });
    return () => { active = false; renderTask?.cancel(); };
  }, [docId, docType, pdfPageCount, pdfPage]);

  function selectDocument(id: string) {
    if (id === selectedId) return;
    setSelectedId(id);
    setDoc(null);
    setZoom(100);
    setPdfPage(1);
    setPdfPageCount(0);
    setMoveImage(false);
    setPreviewOpen(false);
    setRenameTarget(null);
    window.getSelection()?.removeAllRanges();
  }

  function selectFolder(id: string) {
    setActiveFolder(id);
    setSearch("");
    const first = documents.find((item) => id === "all" || (id === "unfiled" ? !item.folderId : item.folderId === id));
    if (first) selectDocument(first.id);
    else { setSelectedId(""); setDoc(null); }
  }

  function startRename(id: string, fileName: string, surface: "card" | "header") {
    setRenameTarget({ id, surface });
    setRenameValue(fileName);
  }

  async function saveRename() {
    const target = renameTarget;
    if (!target) return;
    const name = renameValue.trim();
    if (!name) { setNotice({ text: "Enter a name for the file.", error: true }); return; }
    setRenameTarget(null);
    try {
      await api(`/api/documents/${target.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fileName: name }) });
      setDocuments((items) => items.map((item) => item.id === target.id ? { ...item, fileName: name } : item));
      setDoc((current) => current?.id === target.id ? { ...current, fileName: name } : current);
      setNotice({ text: "File renamed." });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
  }

  async function createFolder() {
    const name = folderName.trim();
    if (!name) return;
    try {
      const result = await api<{ folder: Folder }>("/api/folders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
      await refreshFolders();
      setNewFolder(false); setFolderName(""); selectFolder(result.folder.id);
      setNotice({ text: `Folder “${name}” created.` });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
  }

  async function saveFolderRename() {
    if (activeFolder === "all" || activeFolder === "unfiled") return;
    const name = folderName.trim();
    if (!name) return;
    try {
      await api(`/api/folders/${activeFolder}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
      await refreshFolders();
      setRenamingFolder(false); setFolderName("");
      setNotice({ text: "Folder renamed." });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
  }

  async function moveToFolder(folderId: string) {
    if (!doc) return;
    try {
      await api(`/api/documents/${doc.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ folderId }) });
      setDoc({ ...doc, folderId: folderId || null });
      setDocuments((items) => items.map((item) => item.id === doc.id ? { ...item, folderId: folderId || null } : item));
      setNotice({ text: `Moved to ${folderNameFor(folderId || null)}.` });
      if (activeFolder !== "all" && (activeFolder === "unfiled" ? !!folderId : folderId !== activeFolder)) setActiveFolder("all");
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
  }

  async function upload(file: File | undefined) {
    if (!file) return;
    setBusy("upload"); setNotice(null);
    try {
      const prepared = await prepareImage(file);
      const form = new FormData();
      form.set("file", prepared.file);
      if (activeFolder !== "all" && activeFolder !== "unfiled") form.set("folderId", activeFolder);
      const result = await api<{ id: string; duplicate?: boolean }>("/api/documents", { method: "POST", body: form });
      await refreshDocuments();
      selectDocument(result.id);
      setNotice({ text: result.duplicate ? "This file was already uploaded. Opened the existing copy." : prepared.resized ? "Large photo resized to fit. Check the image, then press Read text." : "Uploaded. Press Read text to start." });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
    finally { setBusy(""); }
  }

  async function importMany() {
    setBusy("import"); setNotice(null);
    try {
      const result = await api<{ imported: { id: string; duplicate: boolean }[]; cancelled?: boolean }>("/api/import", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folderId: activeFolder !== "all" && activeFolder !== "unfiled" ? activeFolder : null }),
      });
      if (result.cancelled) return;
      await refreshDocuments();
      if (result.imported[0]) selectDocument(result.imported[0].id);
      setNotice({ text: `${result.imported.length} ${result.imported.length === 1 ? "file" : "files"} added. Open a document and press Read text.` });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
    finally { setBusy(""); }
  }

  async function openStorage() {
    try { await api("/api/storage/open", { method: "POST" }); }
    catch (error) { setNotice({ text: (error as Error).message, error: true }); }
  }

  async function backupLibrary() {
    setBusy("backup"); setNotice(null);
    try {
      const result = await api<{ destination: string }>("/api/storage/backup", { method: "POST" });
      setNotice({ text: `Backup saved to ${result.destination}` });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
    finally { setBusy(""); }
  }

  async function reviewFile(file: File | undefined, source: "camera" | "upload") {
    if (!file) return;
    setPendingPhoto(null);
    setQualityZoom(false);
    if (file.type === "application/pdf" || /\.pdf$/i.test(file.name)) { await upload(file); return; }
    setBusy("check"); setNotice(null);
    try {
      const issues = await checkPhoto(file).catch((): PhotoIssue[] => ["unchecked"]);
      if (issues.length) setPendingPhoto({ file, url: URL.createObjectURL(file), source, issues });
      else { setPendingPhoto(null); await upload(file); }
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
    finally { setBusy(""); }
  }

  async function readPdfText(pdf: PDFDocumentProxy, onProgress: (message: string) => void): Promise<string> {
    if (pdf.numPages > 20) throw new Error("This first version reads PDFs up to 20 pages. Split this PDF into smaller files.");
    const pageTexts: string[] = [];
    let worker: OcrWorker | undefined;
    try {
      for (let number = 1; number <= pdf.numPages; number++) {
        onProgress(`Reading page ${number} of ${pdf.numPages}…`);
        const page = await pdf.getPage(number);
        const content = await page.getTextContent();
        const embeddedText = content.items.map((item) => "str" in item ? `${item.str}${item.hasEOL ? "\n" : " "}` : "").join("").replace(/[ \t]+\n/g, "\n").trim();
        if (embeddedText.length >= 8) { pageTexts.push(embeddedText); continue; }
        if (!worker) worker = await createOcrWorker(onProgress);
        const base = page.getViewport({ scale: 1 });
        const viewport = page.getViewport({ scale: Math.min(4, 2600 / base.width) });
        const canvas = document.createElement("canvas");
        canvas.width = Math.ceil(viewport.width);
        canvas.height = Math.ceil(viewport.height);
        await page.render({ canvas, viewport }).promise;
        const result = await worker.recognize(canvas);
        pageTexts.push(result.data.text.trim());
      }
      return pageTexts.filter(Boolean).join("\n\n");
    } finally { await worker?.terminate().catch(() => {}); }
  }

  async function runOcr() {
    if (!doc) return;
    setBusy("ocr"); setNotice(null); setProgress("Preparing to read text…");
    let worker: OcrWorker | undefined;
    try {
      let text = "";
      let ocrLayout = "";
      let uncertain = false;
      if (doc.contentType === "application/pdf") {
        if (!pdfRef.current) throw new Error("Wait for the PDF to open, then try again.");
        text = await readPdfText(pdfRef.current, setProgress);
      } else {
        const response = await fetch(`/api/documents/${doc.id}/image`, { cache: "no-store" });
        if (!response.ok) throw new Error("Could not open the image.");
        worker = await createOcrWorker(setProgress);
        const bitmap = await createImageBitmap(await response.blob(), { imageOrientation: "from-image" });
        const canvas = document.createElement("canvas");
        const scale = Math.min(1, 4000 / Math.max(bitmap.width, bitmap.height));
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        canvas.getContext("2d")?.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        bitmap.close();
        const result = await worker.recognize(canvas, {}, { blocks: true });
        text = result.data.text.trim();
        const words = (result.data.blocks || []).flatMap((block) => block.paragraphs.flatMap((paragraph) => paragraph.lines.flatMap((line) => {
          const angle = line.baseline?.has_baseline ? Math.atan2(line.baseline.y1 - line.baseline.y0, line.baseline.x1 - line.baseline.x0) : 0;
          return line.words.map((word) => ({
            text: word.text,
            box: [Math.max(0, word.bbox.x0), Math.max(0, word.bbox.y0), Math.min(canvas.width, word.bbox.x1), Math.min(canvas.height, word.bbox.y1)] as [number, number, number, number],
            confidence: word.confidence,
            angle: Number.isFinite(angle) && Math.abs(angle) <= 1.5 ? angle : 0,
          })).filter((word) => word.text && word.box[0] < word.box[2] && word.box[1] < word.box[3]);
        })));
        const overallConfidence = Number.isFinite(result.data.confidence) ? result.data.confidence : undefined;
        uncertain = needsOcrReview(words, overallConfidence);
        ocrLayout = JSON.stringify({ version: 1, width: canvas.width, height: canvas.height, words: words.slice(0, 10000), overallConfidence });
      }
      await api(`/api/documents/${doc.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ocrText: text, ocrLayout, source: "browser-ocr", status: text ? "Needs Review" : "Cannot Read" }) });
      setDoc({ ...doc, ocrText: text, ocrLayout, source: "browser-ocr" });
      window.getSelection()?.removeAllRanges();
      setNotice({ text: text ? uncertain ? "Some words may be unclear. Check the image carefully before copying." : ocrLayout ? "Text is ready. Select text on the image and press Ctrl+C (or use Copy on your phone). Check it against the original." : "Text is ready. Correct any mistakes, then copy it." : "No text was detected. Try a sharper, well-lit image.", error: !text });
    } catch (error) { setNotice({ text: `Reading failed: ${(error as Error).message}`, error: true }); }
    finally { await worker?.terminate().catch(() => {}); setBusy(""); setProgress(""); }
  }

  async function saveText() {
    if (!doc) return;
    setBusy("save"); setNotice(null);
    try {
      await api(`/api/documents/${doc.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ocrText: doc.ocrText, status: "Needs Review", source: doc.source === "pending" ? "manual" : doc.source }) });
      setNotice({ text: "Corrections saved." });
    } catch (error) { setNotice({ text: (error as Error).message, error: true }); }
    finally { setBusy(""); }
  }

  async function copyText(value: string, label: string) {
    if (!value) { setNotice({ text: "There is no text to copy yet.", error: true }); return; }
    try { await navigator.clipboard.writeText(value); setNotice({ text: `${label} copied. You can paste it into SQL Account.` }); }
    catch { setNotice({ text: "Copy failed. Select the text and use your device’s Copy command.", error: true }); }
  }

  function copySelectedText() {
    const input = textRef.current;
    if (!input || input.selectionStart === input.selectionEnd) { setNotice({ text: "Highlight the text you want first.", error: true }); return; }
    void copyText(input.value.slice(input.selectionStart, input.selectionEnd), "Selected text");
  }

  return <div className="app">
    <header className="top"><div className="brand">Paper to Ledger <span>OCR</span></div><div className="user-menu"><span>{userName}</span><span className="local-label">Local files</span></div></header>
    <main className="wrap">
      <div className="upload-bar"><div><h1>Read a document</h1><p>Import photos or PDFs, or add them to your storage folder. Check the result, then copy what you need.</p><p className="storage-location" title={storagePath}>Stored on this PC: {storagePath}</p></div><div className="upload-actions">
        <button className="btn primary" disabled={!!busy} onClick={() => void importMany()}>Import files</button>
        <label className="btn upload-button">Check one photo<input type="file" accept="image/jpeg,image/png,image/webp,application/pdf,.pdf" disabled={!!busy} onChange={(event) => { const file = event.target.files?.[0]; event.target.value = ""; void reviewFile(file, "upload"); }} /></label>
        <button className="btn" disabled={!!busy} onClick={() => void openStorage()}>Open storage folder</button>
        <button className="btn" disabled={!!busy} onClick={() => void backupLibrary()}>Back up</button>
      </div></div>
      {notice && <div className={`notice${notice.error ? " error" : ""}`} role="status">{notice.text}</div>}
      {busy === "check" && <div className="notice" role="status">Checking photo clarity…</div>}
      {busy === "upload" && <div className="notice" role="status">Uploading…</div>}
      <section className="library" aria-label="Document folders and gallery">
        <div className="library-top"><div><h2>Your documents</h2><p>Choose a folder, then open any photo or PDF.</p></div><button className="btn" type="button" onClick={() => { setNewFolder(true); setRenamingFolder(false); setFolderName(""); }}>+ New folder</button></div>
        <div className="folder-row" aria-label="Folders"><button className={activeFolder === "all" ? "folder active" : "folder"} onClick={() => selectFolder("all")}>All <span>{documents.length}</span></button><button className={activeFolder === "unfiled" ? "folder active" : "folder"} onClick={() => selectFolder("unfiled")}>Unfiled <span>{documents.filter((item) => !item.folderId).length}</span></button>{folders.map((folder) => <button key={folder.id} className={activeFolder === folder.id ? "folder active" : "folder"} onClick={() => selectFolder(folder.id)}>{folder.name} <span>{documents.filter((item) => item.folderId === folder.id).length}</span></button>)}</div>
        {(newFolder || renamingFolder) && <form className="folder-form" onSubmit={(event) => { event.preventDefault(); void (newFolder ? createFolder() : saveFolderRename()); }}><input autoFocus aria-label="Folder name" placeholder="Folder name, e.g. Receipts" maxLength={60} value={folderName} onChange={(event) => setFolderName(event.target.value)} /><button className="btn primary" type="submit">{newFolder ? "Create" : "Save"}</button><button className="btn" type="button" onClick={() => { setNewFolder(false); setRenamingFolder(false); setFolderName(""); }}>Cancel</button></form>}
        <div className="gallery-tools"><span>{visibleDocuments.length} {visibleDocuments.length === 1 ? "document" : "documents"}{activeFolder !== "all" ? ` in ${activeFolder === "unfiled" ? "Unfiled" : folderNameFor(activeFolder)}` : ""}</span><div>{activeFolder !== "all" && activeFolder !== "unfiled" && <button className="subtle-button" type="button" onClick={() => { setFolderName(folderNameFor(activeFolder)); setRenamingFolder(true); setNewFolder(false); }}>Rename folder</button>}<input type="search" aria-label="Find a document" placeholder="Find a file…" value={search} onChange={(event) => setSearch(event.target.value)} /></div></div>
        <div className="gallery">{visibleDocuments.length ? visibleDocuments.map((item) => <article key={item.id} className={item.id === selectedId ? "gallery-card active" : "gallery-card"}><button className="thumbnail" type="button" onClick={() => selectDocument(item.id)} aria-label={`Open ${item.fileName}`}>{item.contentType === "application/pdf" ? <span className="pdf-thumb">PDF</span> : <img src={`/api/documents/${item.id}/image`} alt="" loading="lazy" />}</button><div className="gallery-card-info">{renameTarget?.id === item.id && renameTarget.surface === "card" ? <form onSubmit={(event) => { event.preventDefault(); void saveRename(); }}><input autoFocus aria-label="New filename" value={renameValue} maxLength={180} onChange={(event) => setRenameValue(event.target.value)} onKeyDown={(event) => { if (event.key === "Escape") setRenameTarget(null); }} /><button type="submit">Save</button></form> : <button className="gallery-name" type="button" onClick={() => selectDocument(item.id)} title={item.fileName}>{item.fileName}</button>}<small>{new Date(item.createdAt).toLocaleDateString()} · {folderNameFor(item.folderId)}</small><div className="gallery-card-actions"><button type="button" onClick={() => { selectDocument(item.id); setPreviewOpen(true); }}>Preview</button><button type="button" onClick={() => startRename(item.id, item.fileName, "card")}>Rename</button></div></div></article>) : <p className="gallery-empty">No documents here yet. Upload one or choose another folder.</p>}</div>
      </section>
      <div className="workspace-grid">
        <section className="paper-panel"><div className="panel-heading"><div>{doc && renameTarget?.id === doc.id && renameTarget.surface === "header" ? <form className="header-rename" onSubmit={(event) => { event.preventDefault(); void saveRename(); }}><input autoFocus aria-label="New filename" value={renameValue} maxLength={180} onChange={(event) => setRenameValue(event.target.value)} onKeyDown={(event) => { if (event.key === "Escape") setRenameTarget(null); }} /><button className="btn primary" type="submit">Save</button></form> : <h2>{doc?.fileName || "Original document"}</h2>}<p>Compare this image with the recognized text.</p></div>{doc && <div className="heading-actions"><button type="button" className="subtle-button" onClick={() => startRename(doc.id, doc.fileName, "header")}>Rename</button><button type="button" className="subtle-button" onClick={() => setPreviewOpen(true)}>Full preview</button><a className="text-link" href={`/api/documents/${doc.id}/image`} target="_blank" rel="noreferrer">Open stored file</a></div>}</div>
          {doc && <div className="file-organize"><label htmlFor="move-folder">Folder</label><select id="move-folder" value={doc.folderId || ""} onChange={(event) => void moveToFolder(event.target.value)}><option value="">Unfiled</option>{folders.map((folder) => <option value={folder.id} key={folder.id}>{folder.name}</option>)}</select></div>}
          {doc ? <><div className="viewer-toolbar"><span>Zoom</span><button type="button" onClick={() => setZoom((value) => Math.max(100, value - 25))} disabled={zoom === 100} aria-label="Zoom out">−</button><strong>{zoom}%</strong><button type="button" onClick={() => setZoom((value) => Math.min(250, value + 25))} disabled={zoom === 250} aria-label="Zoom in">+</button>
            {layout && doc.contentType !== "application/pdf" && <><button type="button" className="mode-button" aria-pressed={!moveImage} onClick={() => setMoveImage(false)}>Select text</button><button type="button" className="mode-button" aria-pressed={moveImage} onClick={() => { setMoveImage(true); window.getSelection()?.removeAllRanges(); }}>Move image</button><button type="button" className="mode-button" onClick={() => window.getSelection()?.removeAllRanges()}>Clear highlight</button></>}
            {doc.contentType === "application/pdf" && <div className="page-controls"><button type="button" disabled={pdfPage <= 1} onClick={() => { setPdfLoading(true); setPdfPage((number) => number - 1); }}>‹</button><span>Page {pdfPage} of {pdfPageCount || "…"}</span><button type="button" disabled={!pdfPageCount || pdfPage >= pdfPageCount} onClick={() => { setPdfLoading(true); setPdfPage((number) => number + 1); }}>›</button></div>}
          </div><div className="viewer">{doc.contentType === "application/pdf" ? <><canvas ref={canvasRef} style={{ width: `${zoom}%` }} aria-label={`PDF page ${pdfPage}`} />{pdfLoading && <div className="viewer-loading">Opening page…</div>}</> : <div className="image-stage" style={{ width: `${zoom}%` }}><img src={`/api/documents/${doc.id}/image`} alt="Uploaded document" />{layout && !moveImage && <OcrTextLayer layout={layout} />}</div>}</div></> : <div className="viewer-empty">Choose a photo or PDF to begin.</div>}
        </section>
        <section className="text-panel"><div className="panel-heading"><div><h2>Text to copy</h2><p>Plain, editable text. Copying uses exactly what you see here.</p></div></div>
          <div className="text-panel-body"><button className="btn primary read-button" disabled={!doc || !!busy || (doc.contentType === "application/pdf" && !pdfPageCount)} onClick={runOcr}>{busy === "ocr" ? "Reading…" : doc?.ocrText ? !layout && doc.contentType !== "application/pdf" ? "Enable image selection" : "Read text again" : "Read text"}</button>
            {progress && <p className="progress" role="status">{progress}</p>}
            {doc?.ocrText && uncertainOcr && <p className="ocr-review-warning" role="status">Some text may be unclear. Compare the recognized words with the photo before copying.</p>}
            {layout && !moveImage && <p className="direct-copy-help">Select letters on the image, then press <strong>Ctrl+C</strong>. On a phone, use the selection menu’s <strong>Copy</strong>. The image stays unchanged.</p>}
            <div className="copy-actions"><button className="btn primary" disabled={!doc?.ocrText} onClick={() => void copyText(doc?.ocrText || "", "All text")}>Copy all text</button><button className="btn" disabled={!doc?.ocrText} onMouseDown={(event) => event.preventDefault()} onClick={copySelectedText}>Copy text box selection</button></div>
            <label htmlFor="ocr-text">Recognized text</label><textarea ref={textRef} id="ocr-text" value={doc?.ocrText || ""} disabled={!doc} placeholder="Upload a document and press Read text." onChange={(event) => setDoc((current) => current ? { ...current, ocrText: event.target.value } : null)} />
            <button className="save-button" disabled={!doc || !!busy} onClick={saveText}>Save corrections</button><p className="muted">OCR can misread letters and amounts. Compare the text with the original before using it.</p>
          </div>
        </section>
      </div>
      {previewOpen && doc && <div className="preview-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPreviewOpen(false); }}><div className="preview-dialog" role="dialog" aria-modal="true" aria-label={`Preview ${doc.fileName}`}><div className="preview-heading"><div><strong>{doc.fileName}</strong><span>{folderNameFor(doc.folderId)}</span></div><div><a href={`/api/documents/${doc.id}/image`} target="_blank" rel="noreferrer">Open original</a><button type="button" onClick={() => setPreviewOpen(false)} aria-label="Close preview">×</button></div></div><div className="preview-body">{doc.contentType === "application/pdf" ? <iframe title={doc.fileName} src={`/api/documents/${doc.id}/image`} /> : <div className="preview-image-stage"><img src={`/api/documents/${doc.id}/image`} alt={doc.fileName} />{layout && <OcrTextLayer layout={layout} />}</div>}</div></div></div>}
      {pendingPhoto && <div className="quality-backdrop" role="presentation"><div className="quality-dialog" role="dialog" aria-modal="true" aria-labelledby="quality-title"><div className="quality-heading"><div><h2 id="quality-title">Check this photo</h2><p>The photo stays on this device until you choose to use it.</p></div><div className="quality-heading-actions"><button type="button" onClick={() => setQualityZoom((value) => !value)}>{qualityZoom ? "Zoom out" : "Zoom in"}</button><button type="button" onClick={() => setPendingPhoto(null)} aria-label="Cancel photo">×</button></div></div><div className="quality-body"><div className="quality-image-scroll"><img className={qualityZoom ? "zoomed" : ""} src={pendingPhoto.url} alt="Photo awaiting clarity check" /></div><div className="quality-advice"><strong>This photo may be hard to read</strong><ul>{pendingPhoto.issues.map((issue) => <li key={issue}>{photoIssueMessage[issue]}</li>)}</ul><p>Zoom in on the smallest text. If it looks fuzzy here, OCR may copy it incorrectly.</p></div></div><div className="quality-actions"><button className="btn" type="button" onClick={() => setPendingPhoto(null)}>Cancel</button><label className="btn upload-button">{pendingPhoto.source === "camera" ? "Retake photo" : "Choose another"}<input type="file" accept="image/jpeg,image/png,image/webp" {...(pendingPhoto.source === "camera" ? { capture: "environment" as const } : {})} onChange={(event) => { const file = event.target.files?.[0]; event.target.value = ""; void reviewFile(file, pendingPhoto.source); }} /></label><button className="btn primary" type="button" onClick={() => { const file = pendingPhoto.file; setPendingPhoto(null); void upload(file); }}>Use anyway</button></div></div></div>}
    </main>
  </div>;
}
