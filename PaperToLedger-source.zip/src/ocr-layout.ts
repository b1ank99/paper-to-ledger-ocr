export type OcrWord = {
  text: string;
  box: [number, number, number, number];
  confidence: number;
  angle: number;
};

export type OcrLayout = {
  version: 1;
  width: number;
  height: number;
  words: OcrWord[];
  overallConfidence?: number;
};

export function parseOcrLayout(value: string): OcrLayout | null {
  if (!value) return null;
  try {
    const data: unknown = JSON.parse(value);
    if (!data || typeof data !== "object") return null;
    const layout = data as OcrLayout;
    if (layout.version !== 1 || !Number.isInteger(layout.width) || !Number.isInteger(layout.height) ||
      layout.width < 1 || layout.height < 1 || layout.width > 10000 || layout.height > 10000 ||
      !Array.isArray(layout.words) || layout.words.length > 10000 ||
      (layout.overallConfidence !== undefined && (!Number.isFinite(layout.overallConfidence) || layout.overallConfidence < 0 || layout.overallConfidence > 100))) return null;
    for (const word of layout.words) {
      if (!word || typeof word.text !== "string" || word.text.length > 200 ||
        !Array.isArray(word.box) || word.box.length !== 4 ||
        word.box.some((n) => !Number.isFinite(n)) ||
        word.box[0] < 0 || word.box[1] < 0 || word.box[2] > layout.width || word.box[3] > layout.height ||
        word.box[0] >= word.box[2] || word.box[1] >= word.box[3] ||
        !Number.isFinite(word.confidence) || !Number.isFinite(word.angle) || Math.abs(word.angle) > 1.5) return null;
    }
    return layout;
  } catch { return null; }
}
