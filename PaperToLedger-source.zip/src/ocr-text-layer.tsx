"use client";

import { useEffect, useRef } from "react";
import type { OcrLayout } from "./ocr-layout";

export default function OcrTextLayer({ layout }: { layout: OcrLayout }) {
  const layerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const layer = layerRef.current;
    if (!layer) return;
    const context = document.createElement("canvas").getContext("2d");
    if (!context) return;
    const spans = layer.querySelectorAll<HTMLElement>("[data-ocr-word]");
    spans.forEach((span, index) => {
      const word = layout.words[index];
      if (!word) return;
      const height = word.box[3] - word.box[1];
      context.font = `${height * 1.25}px Arial`;
      const textWidth = context.measureText(word.text).width;
      const targetWidth = word.box[2] - word.box[0];
      const fit = textWidth > 0 ? Math.max(0.25, Math.min(4, targetWidth / textWidth)) : 1;
      span.style.setProperty("--word-fit", String(fit));
    });
  }, [layout]);

  return <div ref={layerRef} className="ocr-native-layer" aria-label="Selectable text on the image">
    {layout.words.map((word, index) => {
      const [x0, y0, , y1] = word.box;
      const height = y1 - y0;
      return <span key={index} className="ocr-native-word" data-ocr-word={index} style={{
        left: `${x0 / layout.width * 100}%`,
        top: `${(y0 - height * 0.1) / layout.height * 100}%`,
        fontSize: `${height * 1.25 / layout.width * 100}cqw`,
        transform: `rotate(${word.angle}rad) scaleX(var(--word-fit, 1))`,
      }}>{word.text}{index < layout.words.length - 1 ? " " : ""}</span>;
    })}
  </div>;
}
