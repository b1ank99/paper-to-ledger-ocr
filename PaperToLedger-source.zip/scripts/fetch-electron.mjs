import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { createRequire } from "node:module";

const packagePath = path.resolve("node_modules/electron");
const electronPackage = JSON.parse(await fsp.readFile(path.join(packagePath, "package.json"), "utf8"));
const fileName = `electron-v${electronPackage.version}-win32-x64.zip`;
const checksums = JSON.parse(await fsp.readFile(path.join(packagePath, "checksums.json"), "utf8"));
const expected = checksums[fileName];
if (!expected) throw new Error("Official Electron checksum is missing.");
const binary = path.join(packagePath, "dist", "electron.exe");
if (fs.existsSync(binary)) { console.log("Electron is already installed."); process.exit(0); }

const downloadDirectory = path.resolve("work/electron-download");
await fsp.mkdir(downloadDirectory, { recursive: true });
const zipPath = path.join(downloadDirectory, fileName);
const url = `https://github.com/electron/electron/releases/download/v${electronPackage.version}/${fileName}`;
async function verified() {
  if (!fs.existsSync(zipPath)) return false;
  const hash = crypto.createHash("sha256");
  for await (const piece of fs.createReadStream(zipPath)) hash.update(piece);
  return hash.digest("hex") === expected;
}
if (!await verified()) {
  const head = await fetch(url, { method: "HEAD", signal: AbortSignal.timeout(30000) });
  if (!head.ok) throw new Error(`Electron download returned ${head.status}.`);
  const total = Number(head.headers.get("content-length"));
  if (!Number.isSafeInteger(total) || total <= 0) throw new Error("Electron download size is unavailable.");
  const initial = await fsp.open(zipPath, "w");
  await initial.truncate(total);
  await initial.close();
  const chunks = 4;
  let downloaded = 0;
  await Promise.all(Array.from({ length: chunks }, async (_, index) => {
    const start = Math.floor(total * index / chunks);
    const end = Math.floor(total * (index + 1) / chunks) - 1;
    const response = await fetch(url, { headers: { Range: `bytes=${start}-${end}` }, signal: AbortSignal.timeout(600000) });
    if (response.status !== 206 || !response.body) throw new Error(`Electron range download failed (${response.status}).`);
    const contentRange = response.headers.get("content-range");
    if (contentRange !== `bytes ${start}-${end}/${total}`) throw new Error("Electron download range did not match.");
    const output = await fsp.open(zipPath, "r+");
    let position = start;
    try {
      for await (const piece of response.body) {
        const bytes = Buffer.from(piece);
        let offset = 0;
        while (offset < bytes.length) {
          const { bytesWritten } = await output.write(bytes, offset, bytes.length - offset, position);
          position += bytesWritten;
          offset += bytesWritten;
        }
        downloaded += bytes.length;
      }
    } finally { await output.close(); }
    if (position !== end + 1) throw new Error("Electron download was incomplete.");
    console.log(`Downloaded ${Math.round(downloaded / total * 100)}%`);
  }));
  if (!await verified()) throw new Error("Electron checksum did not match the official release.");
}
const requireFromElectron = createRequire(path.join(fs.realpathSync(packagePath), "install.js"));
const { extract } = requireFromElectron("@electron-internal/extract-zip");
await fsp.mkdir(path.join(packagePath, "dist"), { recursive: true });
await extract(zipPath, { dir: path.join(packagePath, "dist") });
await fsp.writeFile(path.join(packagePath, "path.txt"), "electron.exe");
console.log("Electron verified and installed.");
