const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { Catalog } = require("../electron/catalog.cjs");

const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/lFUAAAAASUVORK5CYII=", "base64");

test("local files, folder changes, corrections, and backup survive reopening", async () => {
  const scratch = await fs.mkdtemp(path.join(os.tmpdir(), "paper-to-ledger-test-"));
  const root = path.join(scratch, "library");
  const backupParent = path.join(scratch, "backups");
  await fs.mkdir(backupParent);
  let catalog;
  try {
    catalog = new Catalog(root);
    const imported = await catalog.importBuffer("receipt.png", png, null);
    assert.equal(imported.duplicate, false);
    assert.equal(catalog.allDocuments().length, 1);
    await catalog.updateDocument(imported.id, { ocrText: "Corrected total: 12.00", source: "manual" });
    const folder = await catalog.createFolder("September");
    await catalog.updateDocument(imported.id, { folderId: folder.id });
    assert.equal(catalog.fullDocument(imported.id).folderId, folder.id);
    await catalog.renameFolder(folder.id, "Receipts");
    assert.ok((await fs.stat(path.join(root, "Receipts", "receipt.png"))).isFile());
    await fs.rename(path.join(root, "Receipts", "receipt.png"), path.join(root, "Receipts", "renamed.png"));
    await catalog.scan();
    assert.equal(catalog.fullDocument(imported.id).fileName, "renamed.png");
    assert.equal(catalog.fullDocument(imported.id).ocrText, "Corrected total: 12.00");
    const backup = await catalog.createBackup(backupParent);
    assert.ok((await fs.stat(path.join(backup, "Receipts", "renamed.png"))).isFile());
    assert.ok((await fs.stat(path.join(backup, ".paper-to-ledger", "catalog.sqlite"))).isFile());
    catalog.close(); catalog = null;
    catalog = new Catalog(root);
    assert.equal(catalog.fullDocument(imported.id).ocrText, "Corrected total: 12.00");
    await fs.writeFile(path.join(root, "outside.png"), png);
    await catalog.scan();
    assert.equal(catalog.allDocuments().length, 2);
    await fs.unlink(path.join(root, "outside.png"));
    await catalog.scan();
    assert.equal(catalog.allDocuments().length, 1);
  } finally {
    catalog?.close();
    if (scratch.startsWith(os.tmpdir() + path.sep)) await fs.rm(scratch, { recursive: true, force: true });
  }
});
